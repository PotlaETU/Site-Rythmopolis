# Client web Angular

Création d'un client basé sur Angular.

Le client communique avec une API Laravel.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`.


