export enum Role{
  ADMIN = 'admin',
  GESTIONNAIRE = 'gestionnaire',
  ACTIF = 'actif',
  NON_ACTIF = 'non-actif'
}
