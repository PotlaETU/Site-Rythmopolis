export interface Lieu {
  id: number;
  nom: string;
  adresse: string;
  code_postal: string;
  ville: string;
  lat: number;
  long: number;
}
