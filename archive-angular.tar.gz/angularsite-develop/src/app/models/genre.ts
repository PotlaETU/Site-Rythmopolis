export enum Genre {
  POP = 'POP',
  ROCK = 'ROCK',
  CLASSIQUE = 'CLASSIQUE',
  RAP = 'RAP',
  FOLK = 'FOLK',
  SPORTIF = 'SPORTIF',
  COMEDIEN = 'COMEDIEN',
  VARIETE = 'VARIETE',
}
