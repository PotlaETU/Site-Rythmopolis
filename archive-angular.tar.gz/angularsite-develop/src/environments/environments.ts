export const environment = {
  apiURL: "http://localhost:8000/api",
  apiGouv: "https://api-adresse.data.gouv.fr/search/?q="
};
