export const environment = {
  apiURL: "http://localhost:8000/api"
};
