export enum Statut {
  PAYE = 'PAYE',
  EN_ATTENTE = 'EN_ATTENTE',
  ANNULE = 'ANNULE',
  BILLET_EDITE = 'BILLET_EDITE',
}
