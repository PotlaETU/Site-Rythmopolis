export enum Type {
  THEATRE = 'Théatre',
  CINEMA = 'Cinéma',
  CONCERT = 'Concert',
  FESTIVAL = 'Festival',
  COMPETITION = 'Compétition',
}
