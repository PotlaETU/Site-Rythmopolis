import {Genre} from "./genre";

export interface Artiste {
  id: number;
  nom: string;
  genre: Genre;
}
